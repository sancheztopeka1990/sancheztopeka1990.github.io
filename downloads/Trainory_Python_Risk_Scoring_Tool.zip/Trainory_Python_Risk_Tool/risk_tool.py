#!/usr/bin/env python3
"""Trainory risk scoring tool.

Reads human-assessed inherent and residual likelihood/impact values from CSV,
validates the records, calculates risk metrics, and generates CSV/HTML reports.
Uses only the Python standard library.
"""

from __future__ import annotations

import argparse
import csv
import html
import statistics
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable, Mapping


REQUIRED_FIELDS = (
    "risk_id",
    "category",
    "risk_statement",
    "inherent_likelihood",
    "inherent_impact",
    "residual_likelihood",
    "residual_impact",
    "owner",
    "status",
    "target_date",
)

OUTPUT_FIELDS = REQUIRED_FIELDS + (
    "inherent_score",
    "inherent_rating",
    "residual_score",
    "residual_rating",
    "risk_reduction_percent",
    "priority",
    "treatment_guidance",
)


class RiskValidationError(ValueError):
    """Raised when a risk record cannot be scored safely."""


@dataclass(frozen=True)
class RiskResult:
    risk_id: str
    category: str
    risk_statement: str
    inherent_likelihood: int
    inherent_impact: int
    residual_likelihood: int
    residual_impact: int
    owner: str
    status: str
    target_date: str
    inherent_score: int
    inherent_rating: str
    residual_score: int
    residual_rating: str
    risk_reduction_percent: float
    priority: int
    treatment_guidance: str


def rating_for(score: int) -> str:
    """Map a 5x5 score to Trainory's approved qualitative rating."""
    if not 1 <= score <= 25:
        raise RiskValidationError(f"Risk score must be between 1 and 25; received {score}.")
    if score <= 4:
        return "Low"
    if score <= 9:
        return "Moderate"
    if score <= 16:
        return "High"
    return "Critical"


def parse_scale(value: object, field_name: str, risk_id: str) -> int:
    """Parse and validate a likelihood or impact value on the 1-5 scale."""
    try:
        parsed = int(str(value).strip())
    except (TypeError, ValueError) as exc:
        raise RiskValidationError(
            f"{risk_id}: {field_name} must be a whole number from 1 to 5."
        ) from exc
    if not 1 <= parsed <= 5:
        raise RiskValidationError(f"{risk_id}: {field_name} must be from 1 to 5.")
    return parsed


def treatment_for(rating: str) -> str:
    """Provide consistent guidance without replacing management judgment."""
    return {
        "Low": "Monitor or accept with documented approval.",
        "Moderate": "Monitor and mitigate through planned control improvements.",
        "High": "Prioritize mitigation, assign an owner, and track to closure.",
        "Critical": "Escalate promptly; reduce exposure or obtain formal risk acceptance.",
    }[rating]


def assess_record(row: Mapping[str, object]) -> RiskResult:
    """Validate and score one CSV record."""
    risk_id = str(row.get("risk_id", "")).strip()
    if not risk_id:
        raise RiskValidationError("A record is missing risk_id.")

    missing_text = [
        field for field in ("category", "risk_statement", "owner", "status")
        if not str(row.get(field, "")).strip()
    ]
    if missing_text:
        raise RiskValidationError(f"{risk_id}: missing required value(s): {', '.join(missing_text)}.")

    inherent_likelihood = parse_scale(row.get("inherent_likelihood"), "inherent_likelihood", risk_id)
    inherent_impact = parse_scale(row.get("inherent_impact"), "inherent_impact", risk_id)
    residual_likelihood = parse_scale(row.get("residual_likelihood"), "residual_likelihood", risk_id)
    residual_impact = parse_scale(row.get("residual_impact"), "residual_impact", risk_id)

    inherent_score = inherent_likelihood * inherent_impact
    residual_score = residual_likelihood * residual_impact
    if residual_score > inherent_score:
        raise RiskValidationError(
            f"{risk_id}: residual score ({residual_score}) cannot exceed inherent score "
            f"({inherent_score}) without an analyst explanation. Review the inputs."
        )

    inherent_rating = rating_for(inherent_score)
    residual_rating = rating_for(residual_score)
    reduction = round((1 - residual_score / inherent_score) * 100, 1)
    priority = {"Critical": 1, "High": 2, "Moderate": 3, "Low": 4}[residual_rating]

    return RiskResult(
        risk_id=risk_id,
        category=str(row["category"]).strip(),
        risk_statement=str(row["risk_statement"]).strip(),
        inherent_likelihood=inherent_likelihood,
        inherent_impact=inherent_impact,
        residual_likelihood=residual_likelihood,
        residual_impact=residual_impact,
        owner=str(row["owner"]).strip(),
        status=str(row["status"]).strip(),
        target_date=str(row.get("target_date", "")).strip(),
        inherent_score=inherent_score,
        inherent_rating=inherent_rating,
        residual_score=residual_score,
        residual_rating=residual_rating,
        risk_reduction_percent=reduction,
        priority=priority,
        treatment_guidance=treatment_for(residual_rating),
    )


def load_risks(path: Path) -> list[RiskResult]:
    """Load, validate, score, and prioritize all records in a CSV file."""
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise RiskValidationError("Input CSV does not contain a header row.")
        missing = [field for field in REQUIRED_FIELDS if field not in reader.fieldnames]
        if missing:
            raise RiskValidationError(f"Input CSV is missing column(s): {', '.join(missing)}.")
        results = [assess_record(row) for row in reader]

    if not results:
        raise RiskValidationError("Input CSV does not contain any risk records.")
    duplicate_ids = sorted({r.risk_id for r in results if sum(x.risk_id == r.risk_id for x in results) > 1})
    if duplicate_ids:
        raise RiskValidationError(f"Duplicate risk_id value(s): {', '.join(duplicate_ids)}.")
    return sorted(results, key=lambda r: (r.priority, -r.residual_score, r.risk_id))


def write_scored_csv(risks: Iterable[RiskResult], path: Path) -> None:
    """Write the enriched, prioritized risk register."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=OUTPUT_FIELDS)
        writer.writeheader()
        for risk in risks:
            writer.writerow(asdict(risk))


def summarize(risks: list[RiskResult]) -> dict[str, object]:
    """Create summary metrics used by the HTML report and tests."""
    counts = {rating: 0 for rating in ("Critical", "High", "Moderate", "Low")}
    for risk in risks:
        counts[risk.residual_rating] += 1
    return {
        "total": len(risks),
        "material": counts["Critical"] + counts["High"],
        "average_residual": round(statistics.mean(r.residual_score for r in risks), 1),
        "average_reduction": round(statistics.mean(r.risk_reduction_percent for r in risks), 1),
        "counts": counts,
    }


def generate_html(risks: list[RiskResult], path: Path, source_name: str) -> None:
    """Generate a self-contained executive report that opens in any browser."""
    summary = summarize(risks)
    counts = summary["counts"]
    assert isinstance(counts, dict)
    total = int(summary["total"])

    bars = "".join(
        f"""
        <div class="bar-row">
          <span>{rating}</span>
          <div class="track"><div class="bar {rating.lower()}" style="width:{(counts[rating] / total) * 100:.1f}%"></div></div>
          <strong>{counts[rating]}</strong>
        </div>"""
        for rating in ("Critical", "High", "Moderate", "Low")
    )

    rows = "".join(
        f"""
        <tr>
          <td><strong>{html.escape(r.risk_id)}</strong></td>
          <td>{html.escape(r.category)}</td>
          <td>{html.escape(r.risk_statement)}</td>
          <td>{r.inherent_score} <span class="pill {r.inherent_rating.lower()}">{r.inherent_rating}</span></td>
          <td>{r.residual_score} <span class="pill {r.residual_rating.lower()}">{r.residual_rating}</span></td>
          <td>{r.risk_reduction_percent:.1f}%</td>
          <td>{html.escape(r.owner)}</td>
          <td>{html.escape(r.status)}</td>
          <td>{html.escape(r.target_date or "Not set")}</td>
        </tr>"""
        for r in risks
    )

    document = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Trainory Risk Report</title>
  <style>
    :root{{--navy:#16324f;--blue:#2f6690;--pale:#e8f0f7;--ink:#1f2937;--muted:#667085;
      --line:#d9e2ea;--critical:#b42318;--high:#c2410c;--moderate:#a16207;--low:#166534;}}
    *{{box-sizing:border-box}} body{{margin:0;background:#f4f7fa;color:var(--ink);font:15px/1.45 Arial,sans-serif}}
    header{{background:var(--navy);color:white;padding:28px max(24px,calc((100vw - 1220px)/2))}}
    header h1{{margin:0 0 6px;font-size:28px}} header p{{margin:0;color:#d8e6f2}}
    main{{max-width:1220px;margin:24px auto;padding:0 20px 40px}}
    .cards{{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}}
    .card,.panel{{background:white;border:1px solid var(--line);border-radius:10px;box-shadow:0 3px 12px #16324f10}}
    .card{{padding:18px}} .card .label{{font-size:12px;text-transform:uppercase;color:var(--muted);font-weight:bold}}
    .card .value{{font-size:30px;font-weight:800;color:var(--navy);margin-top:5px}}
    .panel{{margin-top:18px;padding:20px}} h2{{margin:0 0 14px;color:var(--navy);font-size:19px}}
    .bar-row{{display:grid;grid-template-columns:90px 1fr 35px;gap:12px;align-items:center;margin:10px 0}}
    .track{{height:14px;background:#edf1f5;border-radius:8px;overflow:hidden}} .bar{{height:100%;min-width:2px}}
    .critical{{background:#dc2626}} .high{{background:#f97316}} .moderate{{background:#eab308}} .low{{background:#16a34a}}
    .table-wrap{{overflow:auto}} table{{width:100%;border-collapse:collapse;min-width:1050px}}
    th{{background:var(--blue);color:white;text-align:left;padding:10px;font-size:12px}}
    td{{padding:10px;border-bottom:1px solid var(--line);vertical-align:top}} tr:hover td{{background:#f8fafc}}
    .pill{{display:inline-block;padding:2px 7px;border-radius:10px;color:white;font-size:11px;margin-left:4px}}
    .note{{color:var(--muted);font-size:13px}} footer{{margin-top:18px;color:var(--muted);font-size:12px}}
    @media(max-width:800px){{.cards{{grid-template-columns:repeat(2,1fr)}}}}
  </style>
</head>
<body>
  <header><h1>Trainory Risk Report</h1><p>Risk scoring and prioritization | Trainory case study</p></header>
  <main>
    <section class="cards">
      <div class="card"><div class="label">Total risks</div><div class="value">{summary['total']}</div></div>
      <div class="card"><div class="label">High / Critical</div><div class="value">{summary['material']}</div></div>
      <div class="card"><div class="label">Average residual score</div><div class="value">{summary['average_residual']}</div></div>
      <div class="card"><div class="label">Average risk reduction</div><div class="value">{summary['average_reduction']}%</div></div>
    </section>
    <section class="panel"><h2>Residual risk distribution</h2>{bars}</section>
    <section class="panel">
      <h2>Prioritized risk register</h2>
      <p class="note">Sorted by residual rating and score. Ratings support decisions; risk owners and leadership retain judgment.</p>
      <div class="table-wrap"><table>
        <thead><tr><th>Risk</th><th>Category</th><th>Statement</th><th>Inherent</th><th>Residual</th><th>Reduction</th><th>Owner</th><th>Status</th><th>Target</th></tr></thead>
        <tbody>{rows}</tbody>
      </table></div>
    </section>
    <footer>Source: {html.escape(source_name)}. Trainory and all records are fictional. Generated by risk_tool.py.</footer>
  </main>
</body>
</html>"""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(document, encoding="utf-8")


def build_parser() -> argparse.ArgumentParser:
    base = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Score and prioritize a Trainory CSV risk register.")
    parser.add_argument("--input", type=Path, default=base / "sample_risks.csv", help="Input CSV path")
    parser.add_argument("--csv-output", type=Path, default=base / "generated" / "scored_risks.csv", help="Scored CSV output path")
    parser.add_argument("--html-output", type=Path, default=base / "generated" / "risk_report.html", help="HTML report output path")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        risks = load_risks(args.input)
        write_scored_csv(risks, args.csv_output)
        generate_html(risks, args.html_output, args.input.name)
    except (OSError, RiskValidationError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    summary = summarize(risks)
    print(f"Scored {summary['total']} risks.")
    print(f"High/Critical residual risks: {summary['material']}")
    print(f"CSV report: {args.csv_output.resolve()}")
    print(f"HTML report: {args.html_output.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
