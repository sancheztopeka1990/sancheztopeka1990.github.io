@echo off
setlocal
cd /d "%~dp0"
python risk_tool.py
if errorlevel 1 (
  echo.
  echo The demo did not complete. Confirm that Python is installed and review the error above.
  pause
  exit /b 1
)
echo.
echo The reports are ready in the generated folder.
start "" "generated\risk_report.html"
pause
