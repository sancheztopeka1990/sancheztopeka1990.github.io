#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
python3 risk_tool.py
printf '%s\n' "The reports are ready in the generated folder."
