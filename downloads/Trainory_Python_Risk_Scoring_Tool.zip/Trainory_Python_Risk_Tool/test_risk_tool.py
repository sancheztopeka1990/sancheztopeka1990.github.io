import csv
import tempfile
import unittest
from pathlib import Path

from risk_tool import RiskValidationError, assess_record, generate_html, load_risks, rating_for, summarize


BASE_RECORD = {
    "risk_id": "TRN-TEST",
    "category": "Testing",
    "risk_statement": "A controlled test record could be scored incorrectly.",
    "inherent_likelihood": "4",
    "inherent_impact": "5",
    "residual_likelihood": "3",
    "residual_impact": "5",
    "owner": "Cybersecurity / IT",
    "status": "Open",
    "target_date": "2026-12-31",
}


class RiskToolTests(unittest.TestCase):
    def test_rating_boundaries(self):
        expected = {1: "Low", 4: "Low", 5: "Moderate", 9: "Moderate", 10: "High", 16: "High", 17: "Critical", 25: "Critical"}
        for score, rating in expected.items():
            self.assertEqual(rating_for(score), rating)

    def test_scoring_and_reduction(self):
        result = assess_record(BASE_RECORD)
        self.assertEqual(result.inherent_score, 20)
        self.assertEqual(result.inherent_rating, "Critical")
        self.assertEqual(result.residual_score, 15)
        self.assertEqual(result.residual_rating, "High")
        self.assertEqual(result.risk_reduction_percent, 25.0)
        self.assertEqual(result.priority, 2)

    def test_rejects_out_of_range_scale(self):
        record = dict(BASE_RECORD, residual_impact="6")
        with self.assertRaises(RiskValidationError):
            assess_record(record)

    def test_rejects_residual_above_inherent(self):
        record = dict(BASE_RECORD, inherent_likelihood="2", inherent_impact="2")
        with self.assertRaises(RiskValidationError):
            assess_record(record)

    def test_csv_load_summary_and_html_escaping(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            folder = Path(temp_dir)
            csv_path = folder / "risks.csv"
            with csv_path.open("w", encoding="utf-8", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=BASE_RECORD.keys())
                writer.writeheader()
                writer.writerow(dict(BASE_RECORD, risk_statement="Test <script>alert(1)</script>"))
            risks = load_risks(csv_path)
            self.assertEqual(summarize(risks)["material"], 1)
            report = folder / "report.html"
            generate_html(risks, report, csv_path.name)
            content = report.read_text(encoding="utf-8")
            self.assertIn("&lt;script&gt;", content)
            self.assertNotIn("<script>alert", content)


if __name__ == "__main__":
    unittest.main()
