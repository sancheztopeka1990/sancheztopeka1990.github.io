# Trainory Python Risk Scoring Tool

This dependency-free Python utility validates, scores, prioritizes, and reports cybersecurity risks from a CSV risk register. It uses fictional Trainory fitness-technology data and runs with the Python standard library.

## What it does

- Reads a CSV risk register.
- Validates required fields and 1–5 likelihood/impact values.
- Calculates inherent and residual risk scores.
- Applies Trainory's approved 5×5 rating thresholds.
- Calculates estimated risk reduction.
- Prioritizes the register by residual exposure.
- Generates a scored CSV for analysis.
- Generates a self-contained HTML report for leadership.
- Escapes HTML content and rejects questionable scoring inputs.

The tool does **not** decide likelihood, impact, or risk acceptance. Those inputs still require analyst, risk-owner, and leadership judgment.

## Run it on Windows

1. Install a current version of Python from `https://www.python.org/downloads/` if Python is not already installed.
2. Extract this project folder.
3. Double-click `run_demo.bat`.
4. Open `generated/risk_report.html` in any browser.
5. Open `generated/scored_risks.csv` in Excel if you want to review or filter the results.

You can also run it from Command Prompt or PowerShell:

```text
python risk_tool.py
```

To score another file:

```text
python risk_tool.py --input my_risks.csv --csv-output generated/my_scored_risks.csv --html-output generated/my_report.html
```

## Run the tests

```text
python -m unittest -v
```

## Files

- `risk_tool.py` — application code and command-line interface.
- `sample_risks.csv` — 15 fictional Trainory risks.
- `input_template.csv` — blank import template with the required columns.
- `test_risk_tool.py` — automated tests for thresholds, calculations, validation, CSV loading, and HTML escaping.
- `run_demo.bat` — one-click Windows demonstration.
- `run_demo.sh` — macOS/Linux demonstration.
- `generated/scored_risks.csv` — enriched output created by the program.
- `generated/risk_report.html` — browser-friendly executive report created by the program.

## Scoring model

| Score | Rating |
|---:|---|
| 1–4 | Low |
| 5–9 | Moderate |
| 10–16 | High |
| 17–25 | Critical |

`Risk score = Likelihood × Impact`

`Risk reduction % = (1 − Residual score ÷ Inherent score) × 100`

## Technical design

- Python standard library only; no external packages are required.
- CSV input and output support exchange with Excel and other analysis tools.
- Command-line options allow users to select input and output paths without changing code.
- Validation checks required fields, numeric ranges, dates, and score consistency before processing.
- Functions and a dataclass separate parsing, validation, scoring, summarization, and reporting.
- HTML and CSS produce a self-contained report that opens locally in a browser.
- Unit tests cover threshold boundaries, calculations, validation failures, file loading, and HTML escaping.

## Limitations

- The tool applies a defined scoring model; it does not determine likelihood, impact, treatment, or risk acceptance.
- It does not provide authentication, workflow approvals, database storage, or multi-user access.
- Generated reports depend on the quality and completeness of the source CSV.

## Case study notice

Trainory, its risks, owners, dates, and decisions are fictional. This tool is not an audit opinion or production risk-management system.
