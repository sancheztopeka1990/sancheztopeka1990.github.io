# Trainory Python Risk Scoring Tool

This small portfolio project demonstrates how a GRC analyst can use Python to validate, score, prioritize, and report cybersecurity risks. It uses fictional Trainory fitness-technology data and only the Python standard library—no paid products, accounts, domains, or package installation are required.

## What it does

- Reads a CSV risk register.
- Validates required fields and 1–5 likelihood/impact values.
- Calculates inherent and residual risk scores.
- Applies Trainory's approved 5×5 rating thresholds.
- Calculates estimated risk reduction.
- Prioritizes the register by residual exposure.
- Generates a scored CSV for analysis.
- Generates a self-contained HTML report for leadership.
- Escapes HTML content and rejects questionable scoring inputs.

The tool does **not** decide likelihood, impact, or risk acceptance. Those inputs still require analyst, risk-owner, and leadership judgment.

## Run it on Windows

1. Install a current version of Python from `https://www.python.org/downloads/` if Python is not already installed.
2. Extract this project folder.
3. Double-click `run_demo.bat`.
4. Open `generated/risk_report.html` in any browser.
5. Open `generated/scored_risks.csv` in Excel if you want to review or filter the results.

You can also run it from Command Prompt or PowerShell:

```text
python risk_tool.py
```

To score another file:

```text
python risk_tool.py --input my_risks.csv --csv-output generated/my_scored_risks.csv --html-output generated/my_report.html
```

## Run the tests

```text
python -m unittest -v
```

## Files

- `risk_tool.py` — application code and command-line interface.
- `sample_risks.csv` — 15 fictional Trainory risks.
- `input_template.csv` — blank import template with the required columns.
- `test_risk_tool.py` — automated tests for thresholds, calculations, validation, CSV loading, and HTML escaping.
- `run_demo.bat` — one-click Windows demonstration.
- `run_demo.sh` — macOS/Linux demonstration.
- `generated/scored_risks.csv` — enriched output created by the program.
- `generated/risk_report.html` — browser-friendly executive report created by the program.

## Scoring model

| Score | Rating |
|---:|---|
| 1–4 | Low |
| 5–9 | Moderate |
| 10–16 | High |
| 17–25 | Critical |

`Risk score = Likelihood × Impact`

`Risk reduction % = (1 − Residual score ÷ Inherent score) × 100`

## How to explain the technology

- **Python:** the programming language used to create the tool.
- **CSV:** a simple table-based file format used to exchange risk data with Excel and other systems.
- **Command-line interface:** lets a user select input and output files without changing the code.
- **Validation:** checks that required values exist and that ratings stay on the approved scale.
- **Functions and dataclass:** organize the program into understandable, reusable pieces and define a consistent output record.
- **HTML/CSS:** creates a report that opens locally in a browser without hosting.
- **Unit tests:** automatically confirm that scoring thresholds, safeguards, and outputs behave as expected.

## Interview-ready explanation

> I built a dependency-free Python tool that reads a CSV risk register, validates the analyst's inputs, calculates inherent and residual risk, and creates prioritized CSV and HTML reports. I separated the scoring, validation, reporting, and command-line functions so the code is easier to test and maintain. I also added automated tests for threshold boundaries and unsafe inputs. The program supports GRC decisions, but it intentionally does not replace human judgment about likelihood, impact, remediation, or risk acceptance.

## Portfolio disclaimer

Trainory, its risks, owners, dates, and decisions are fictional educational examples. This project is not an audit opinion or production risk-management system.
